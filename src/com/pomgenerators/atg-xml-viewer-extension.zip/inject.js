(function () {
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.bottom = '10px';
  container.style.right = '10px';
  container.style.zIndex = '9999';
  container.style.border = '1px solid #ccc';
  container.style.background = '#fff';
  container.style.boxShadow = '0 0 8px rgba(0,0,0,0.3)';
  container.style.padding = '5px';

  const btn = document.createElement('button');
  btn.textContent = 'ATG XML Viewer';
  btn.onclick = () => {
    const win = window.open(chrome.runtime.getURL('viewer.html'), '_blank');
    win.focus();
  };

  container.appendChild(btn);
  document.body.appendChild(container);
})();